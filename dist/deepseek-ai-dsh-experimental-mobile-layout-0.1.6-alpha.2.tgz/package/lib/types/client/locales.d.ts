/** Localized feature labels. */
export declare const zh: {
    navigation: string;
    menu: string;
    chat: string;
};
/** English counterpart. */
export declare const en: Record<keyof typeof zh, string>;
//# sourceMappingURL=locales.d.ts.map