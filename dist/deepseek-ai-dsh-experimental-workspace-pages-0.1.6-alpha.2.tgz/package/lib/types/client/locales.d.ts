/** Localized feature labels. */
export declare const zh: {
    download: string;
    preview: string;
    files: string;
};
/** English counterpart. */
export declare const en: {
    download: string;
    preview: string;
    files: string;
};
//# sourceMappingURL=locales.d.ts.map