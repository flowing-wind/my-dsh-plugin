/** Localized workspace deletion controls. */
/** Workspace management labels. */
export declare const zh: {
    deleteSession: string;
    allSessions: string;
    sessionNote: string;
    filesUnavailable: string;
    title: string;
    subtitle: string;
    sessions: string;
    workspaces: string;
    remove: string;
    cancel: string;
    confirm: string;
    confirmation: string;
    retain: string;
    files: string;
    filesNote: string;
    error: string;
    loading: string;
    refresh: string;
    pending: string;
    empty: string;
};
/** English workspace management labels. */
export declare const en: Record<keyof typeof zh, string>;
//# sourceMappingURL=locales.d.ts.map