import type { Context } from '@deepseek-ai/cordis';
import { zh } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        workspaceManagement: keyof typeof zh;
    }
}
/** Browser registration dependencies. */
export declare const inject: string[];
/** @param ctx - Browser slot and locale services. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=view.d.ts.map