/** Browser entry for conversation and workspace management. */
export { apply, inject } from './actions.tsx';
//# sourceMappingURL=index.d.ts.map