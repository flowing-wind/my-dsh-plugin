/** Browser-only wallpaper persistence, keeping image bytes out of Host requests. */
/**
 * Read or replace this browser's custom wallpaper.
 * @param value - Omit to read, pass null to clear, or pass a Blob to save.
 * @returns The stored image, or null when no custom wallpaper is selected.
 */
export declare function wallpaperStorage(value?: Blob | null): Promise<Blob | null>;
/**
 * Compress one browser-selected image for local storage.
 * @param file - Browser-selected raster image.
 * @returns Locally resized WebP image.
 */
export declare function compressWallpaper(file: File): Promise<Blob>;
//# sourceMappingURL=storage.d.ts.map