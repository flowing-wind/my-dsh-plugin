/** Browser-local wallpapers beside the native Harness appearance. */
import type { Context } from '@deepseek-ai/cordis';
import { zh } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        glassSkin: keyof typeof zh;
    }
}
/** Browser services used by the background settings and official wordmark. */
export declare const inject: string[];
/** @param ctx - Browser context owning removable styles and local background preferences. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=view.d.ts.map