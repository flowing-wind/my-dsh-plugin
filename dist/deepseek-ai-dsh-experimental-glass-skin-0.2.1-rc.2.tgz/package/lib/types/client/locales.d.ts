/** Chinese background settings. */
export declare const zh: {
    presets: string;
    native: string;
    oregairu: string;
    whiteout: string;
    title: string;
    opacity: string;
    hint: string;
    nativeHint: string;
    choose: string;
    local: string;
    custom: string;
    error: string;
    busy: string;
};
/** English background settings. */
export declare const en: {
    presets: string;
    native: string;
    oregairu: string;
    whiteout: string;
    title: string;
    opacity: string;
    hint: string;
    nativeHint: string;
    choose: string;
    local: string;
    custom: string;
    error: string;
    busy: string;
};
//# sourceMappingURL=locales.d.ts.map