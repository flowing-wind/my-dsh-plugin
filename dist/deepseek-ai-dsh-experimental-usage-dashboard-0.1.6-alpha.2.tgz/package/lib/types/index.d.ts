/** Host loader entry for the independently composed browser dashboard. */
/** Register the browser-only plugin with the Host loader. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map