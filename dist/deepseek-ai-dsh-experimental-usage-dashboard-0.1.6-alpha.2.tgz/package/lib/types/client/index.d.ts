/** Shared navigation and section slots for independently removable usage plugins. */
import type { Context } from '@deepseek-ai/cordis';
import { zh } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        usageDashboard: keyof typeof zh;
    }
    interface SlotMap {
        /** Independently owned statistics sections in the unified dashboard. */
        'usage-dashboard.section': {
            kind: 'list';
            scope: 'root';
        };
    }
}
/** Browser composition dependencies. */
export declare const inject: string[];
/** @param ctx - Browser slot and locale services. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map