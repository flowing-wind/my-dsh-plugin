/** Shared dashboard navigation and introduction. */
export declare const zh: {
    title: string;
    subtitle: string;
};
/** English dashboard labels. */
export declare const en: Record<keyof typeof zh, string>;
//# sourceMappingURL=locales.d.ts.map