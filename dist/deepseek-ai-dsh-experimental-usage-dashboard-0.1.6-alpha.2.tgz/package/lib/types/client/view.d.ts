/** Usage dashboard chrome; feature plugins own their data and sections. */
import type { ReactNode } from 'react';
import type { PropsLocale, PropsRenderSlots } from '@deepseek-ai/dsh-client-ui-slots';
/** @returns Unified usage navigation icon. */
export declare function DashboardIcon(): ReactNode;
/** @param props - Localized chrome and independently registered sections. @returns Unified dashboard. */
export declare function Dashboard({ t, renderSlot }: PropsLocale<'usageDashboard'> & PropsRenderSlots<'usage-dashboard.section'>): ReactNode;
//# sourceMappingURL=view.d.ts.map