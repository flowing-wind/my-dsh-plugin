/** Localized feature labels. */
export declare const zh: {
    title: string;
    search: string;
    send: string;
    sent: string;
    sending: string;
    failed: string;
    loading: string;
    local: string;
};
/** English counterpart. */
export declare const en: Record<keyof typeof zh, string>;
//# sourceMappingURL=locales.d.ts.map