/** Durable server-side scheduled prompts, independent of browser connections. */
import type { Context } from '@deepseek-ai/cordis';
import schema from '@deepseek-ai/schemastery';
/** Server polling period. */
export interface Config {
    pollMs: number;
}
/** Deployment scheduling cadence. */
export declare const Config: schema<Config>;
/** Durable state, workspace ownership, prompt admission, and authenticated transport. */
export declare const inject: string[];
/** @param ctx - Host services. @param config - Scheduler polling cadence. */
export declare function apply(ctx: Context, config: Config): Promise<void>;
//# sourceMappingURL=index.d.ts.map