/** Server task scheduling and live conversation navigation. */
import type { Context } from '@deepseek-ai/cordis';
import { zh } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        taskBoard: keyof typeof zh;
    }
}
/** Browser services and conversation navigation. */
export declare const inject: string[];
/** @param ctx - Browser composition context. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=view.d.ts.map