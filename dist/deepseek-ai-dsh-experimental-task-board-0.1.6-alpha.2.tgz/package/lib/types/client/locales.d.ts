/** Localized feature labels. */
export declare const zh: {
    title: string;
    create: string;
    name: string;
    prompt: string;
    workspace: string;
    time: string;
    repeat: string;
    once: string;
    daily: string;
    weekly: string;
    submit: string;
    pause: string;
    resume: string;
    run: string;
    remove: string;
    deleteConfirm: string;
    open: string;
    running: string;
    idle: string;
    scheduled: string;
    dispatching: string;
    submitted: string;
    error: string;
    paused: string;
    active: string;
    none: string;
    note: string;
    loading: string;
    failure: string;
    refresh: string;
};
/** English counterpart. */
export declare const en: Record<keyof typeof zh, string>;
//# sourceMappingURL=locales.d.ts.map