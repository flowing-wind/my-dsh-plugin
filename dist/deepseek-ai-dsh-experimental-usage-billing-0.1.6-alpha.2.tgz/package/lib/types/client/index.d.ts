/** Optional billing dashboard and per-conversation estimate badge. */
import type { Context } from '@deepseek-ai/cordis';
import { zh } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        usageBilling: keyof typeof zh;
    }
}
/** Services needed by the independent billing surface. */
export declare const inject: string[];
/** @param ctx - Browser plugin context. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map