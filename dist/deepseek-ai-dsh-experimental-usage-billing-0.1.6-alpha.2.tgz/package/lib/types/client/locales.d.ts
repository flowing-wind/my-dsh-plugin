/** Billing labels owned by the optional usage plugin. */
export declare const zh: {
    ungrouped: string;
    unnamed: string;
    archived: string;
    subtotal: string;
    todayTokens: string;
    todayCost: string;
    lifetimeCost: string;
    title: string;
    balance: string;
    total: string;
    tokens: string;
    hit: string;
    peak: string;
    offPeak: string;
    unknown: string;
    session: string;
    input: string;
    output: string;
    cost: string;
    refresh: string;
    loading: string;
    error: string;
    unavailable: string;
    notice: string;
    unpriced: string;
    current: string;
    empty: string;
    deleted: string;
    details: string;
};
/** Exact English counterpart of the billing namespace. */
export declare const en: Record<keyof typeof zh, string>;
//# sourceMappingURL=locales.d.ts.map