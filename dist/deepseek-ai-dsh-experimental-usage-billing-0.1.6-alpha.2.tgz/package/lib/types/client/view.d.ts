import type { ReactNode } from 'react';
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** @param props - Root Session metadata and localized labels. @returns Usage dashboard. */
export declare function BillingPage({ t, useSessions, useWorkspaces }: PropsRuntime<'usage-dashboard.section'> & PropsLocale<'usageBilling'>): ReactNode;
/** @param props - Bound Session and localized labels. @returns Per-Session cost and current tariff. */
export declare function BillingBadge({ t, sessionId }: PropsRuntime<'conversation.composer.dock'> & PropsLocale<'usageBilling'>): ReactNode;
//# sourceMappingURL=view.d.ts.map