/** Validated values shared by the billing endpoint and its browser plugin. */
import { z } from 'zod';
/** Token totals and estimated CNY shared by daily and lifetime counters. */
export declare const billingTotalsSchema: z.ZodObject<{
    cny: z.ZodNumber;
    inputTokens: z.ZodNumber;
    outputTokens: z.ZodNumber;
    cacheReadTokens: z.ZodNumber;
    cacheWriteTokens: z.ZodNumber;
    unpricedRequests: z.ZodNumber;
}, z.core.$strip>;
/** Per-Session details; legacy ledgers acquire daily buckets when their logs are replayed. */
export declare const billingRecordSchema: z.ZodObject<{
    cny: z.ZodNumber;
    inputTokens: z.ZodNumber;
    outputTokens: z.ZodNumber;
    cacheReadTokens: z.ZodNumber;
    cacheWriteTokens: z.ZodNumber;
    unpricedRequests: z.ZodNumber;
    updatedAt: z.ZodNumber;
    days: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodObject<{
        cny: z.ZodNumber;
        inputTokens: z.ZodNumber;
        outputTokens: z.ZodNumber;
        cacheReadTokens: z.ZodNumber;
        cacheWriteTokens: z.ZodNumber;
        unpricedRequests: z.ZodNumber;
    }, z.core.$strip>>>;
}, z.core.$strip>;
/** Provider balance response, without credentials or other account data. */
export declare const balanceSchema: z.ZodObject<{
    is_available: z.ZodBoolean;
    balance_infos: z.ZodArray<z.ZodObject<{
        currency: z.ZodString;
        total_balance: z.ZodString;
        granted_balance: z.ZodString;
        topped_up_balance: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>;
/** Authenticated dashboard response. */
export declare const billingSnapshotSchema: z.ZodObject<{
    sessions: z.ZodRecord<z.ZodString, z.ZodObject<{
        cny: z.ZodNumber;
        inputTokens: z.ZodNumber;
        outputTokens: z.ZodNumber;
        cacheReadTokens: z.ZodNumber;
        cacheWriteTokens: z.ZodNumber;
        unpricedRequests: z.ZodNumber;
        updatedAt: z.ZodNumber;
        days: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodObject<{
            cny: z.ZodNumber;
            inputTokens: z.ZodNumber;
            outputTokens: z.ZodNumber;
            cacheReadTokens: z.ZodNumber;
            cacheWriteTokens: z.ZodNumber;
            unpricedRequests: z.ZodNumber;
        }, z.core.$strip>>>;
    }, z.core.$strip>>;
    totals: z.ZodObject<{
        cny: z.ZodNumber;
        inputTokens: z.ZodNumber;
        outputTokens: z.ZodNumber;
        cacheReadTokens: z.ZodNumber;
        cacheWriteTokens: z.ZodNumber;
        unpricedRequests: z.ZodNumber;
    }, z.core.$strip>;
    daily: z.ZodObject<{
        cny: z.ZodNumber;
        inputTokens: z.ZodNumber;
        outputTokens: z.ZodNumber;
        cacheReadTokens: z.ZodNumber;
        cacheWriteTokens: z.ZodNumber;
        unpricedRequests: z.ZodNumber;
    }, z.core.$strip>;
    day: z.ZodString;
    balance: z.ZodOptional<z.ZodObject<{
        fetchedAt: z.ZodNumber;
        value: z.ZodObject<{
            is_available: z.ZodBoolean;
            balance_infos: z.ZodArray<z.ZodObject<{
                currency: z.ZodString;
                total_balance: z.ZodString;
                granted_balance: z.ZodString;
                topped_up_balance: z.ZodString;
            }, z.core.$strip>>;
        }, z.core.$strip>;
    }, z.core.$strip>>;
    balanceError: z.ZodOptional<z.ZodString>;
    period: z.ZodEnum<{
        peak: "peak";
        offPeak: "offPeak";
        unknown: "unknown";
    }>;
    refreshMs: z.ZodNumber;
}, z.core.$strip>;
/** Parsed browser response. */
export type BillingSnapshot = z.infer<typeof billingSnapshotSchema>;
//# sourceMappingURL=wire.d.ts.map