import type { SessionEvent } from '@deepseek-ai/dsh-session';
import type { PricingCalendar, TokenPrices } from './pricing.ts';
/** One dated price generation, selected by request start time. */
export interface PriceGeneration extends PricingCalendar {
    /** Adapter identifier whose reported usage uses these prices. */
    provider: string;
    /** Inclusive effective time as Unix milliseconds. */
    effectiveAt: number;
    /** Beijing holiday dates excluded from peak pricing, formatted YYYY-MM-DD. */
    holidays: string[];
    /** Model identifiers mapped to prices for both billing periods. */
    models: Record<string, {
        /** Weekday peak-period prices. */
        peak: TokenPrices;
        /** Prices outside peak hours and on holidays. */
        offPeak: TokenPrices;
    }>;
}
/** Session estimate excludes inherited fork history and identifies unpriced requests. */
export interface SessionEstimate {
    cny: number;
    inputTokens: number;
    outputTokens: number;
    cacheReadTokens: number;
    cacheWriteTokens: number;
    unpricedRequests: number;
}
/**
 * Fold reported usage, retaining the provider's replacement semantics within an attempt.
 * @param events - Complete ordered logical Session events.
 * @param inheritedEventCount - Fork prefix already billed to another Session.
 * @param generations - Price generations ordered by increasing effectiveAt.
 * @param day - Optional Beijing billing date to include, formatted YYYY-MM-DD.
 * @returns Local token counts and an estimate, with missing prices explicitly counted.
 */
export declare function estimateSession(events: readonly SessionEvent[], inheritedEventCount: number, generations: readonly PriceGeneration[], day?: string): SessionEstimate;
/** @param time - Unix milliseconds. @returns Beijing calendar date. */
export declare function billingDate(time: number): string;
/**
 * Group reported usage by the request's Beijing start date.
 * @param events - Ordered Session events.
 * @param inheritedEventCount - Already billed fork prefix.
 * @param generations - Configured price history.
 * @returns Per-day token counts and estimated charges.
 */
export declare function estimateDays(events: readonly SessionEvent[], inheritedEventCount: number, generations: readonly PriceGeneration[]): Record<string, SessionEstimate>;
//# sourceMappingURL=estimate.d.ts.map