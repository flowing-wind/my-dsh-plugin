/** Optional CNY usage ledger and authenticated balance endpoint for the Web profile. */
import { Context, Service } from '@deepseek-ai/cordis';
import schema from '@deepseek-ai/schemastery';
import { z } from 'zod';
import type { SessionId } from '@deepseek-ai/dsh-session';
import type { PriceGeneration, SessionEstimate } from './estimate.ts';
/** Deployment prices and bounded balance refresh settings. */
export interface Config {
    /** Price versions ordered by strictly increasing effective time. */
    generations: PriceGeneration[];
    /** Credential reference used for balance requests. */
    apiKeyEnv: string;
    /** HTTPS endpoint returning the provider account balance. */
    balanceUrl: string;
    /** Minimum interval between balance refreshes, in milliseconds. */
    balanceCacheMs: number;
    /** Balance request timeout in milliseconds. */
    requestTimeoutMs: number;
    /** Browser refresh interval in milliseconds. */
    refreshMs: number;
}
/** Durable per-Session totals survive deletion of the original conversation. */
export declare const billingDomain: {
    name: string;
    version: number;
    global: {
        schema: z.ZodObject<{
            totals: z.ZodObject<{
                cny: z.ZodNumber;
                inputTokens: z.ZodNumber;
                outputTokens: z.ZodNumber;
                cacheReadTokens: z.ZodNumber;
                cacheWriteTokens: z.ZodNumber;
                unpricedRequests: z.ZodNumber;
            }, z.core.$strip>;
            days: z.ZodRecord<z.ZodString, z.ZodObject<{
                cny: z.ZodNumber;
                inputTokens: z.ZodNumber;
                outputTokens: z.ZodNumber;
                cacheReadTokens: z.ZodNumber;
                cacheWriteTokens: z.ZodNumber;
                unpricedRequests: z.ZodNumber;
            }, z.core.$strip>>;
            pending: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>;
        initial: {
            totals: SessionEstimate;
            days: {};
            pending: null;
        };
    };
    tables: {
        sessions: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<SessionId, {
            cny: number;
            inputTokens: number;
            outputTokens: number;
            cacheReadTokens: number;
            cacheWriteTokens: number;
            unpricedRequests: number;
            updatedAt: number;
            days: Record<string, {
                cny: number;
                inputTokens: number;
                outputTokens: number;
                cacheReadTokens: number;
                cacheWriteTokens: number;
                unpricedRequests: number;
            }>;
        }>;
    };
};
/** Usage estimates with account balances fetched only by an authenticated browser request. */
export declare class UsageBilling extends Service {
    private readonly config;
    static inject: string[];
    static Config: schema<Config>;
    private table;
    private retired;
    private pruning;
    private readonly lifetime;
    private readonly pending;
    private readonly refreshes;
    private balance;
    private balanceRequest;
    /** @param ctx - Host services. @param config - Explicit deployment prices and refresh limits. */
    constructor(ctx: Context, config: Config);
    protected [Service.init](): Promise<void>;
    private track;
    private refresh;
    private enqueueRefresh;
    private readBalance;
    private snapshot;
}
export default UsageBilling;
//# sourceMappingURL=index.d.ts.map