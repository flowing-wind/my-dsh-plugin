export declare const zh: {
    readonly title: "个性化";
    readonly heading: "个性化要求";
    readonly description: "为所有对话向 Agent 提供额外说明和上下文。工作区中的 AGENTS.md 仍会按原有规则生效。";
    readonly save: "保存";
    readonly saved: "已保存";
    readonly saving: "正在保存…";
    readonly failed: "保存失败：{message}";
    readonly placeholder: "填写希望 Agent 始终遵循的要求";
};
export declare const en: Record<keyof typeof zh, string>;
//# sourceMappingURL=locales.d.ts.map