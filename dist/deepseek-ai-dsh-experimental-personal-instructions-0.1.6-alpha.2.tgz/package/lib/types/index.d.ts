/** Home-scoped personal instructions exposed to the model and settings UI. */
import type { Context } from '@deepseek-ai/cordis';
import schema from '@deepseek-ai/schemastery';
/** Personal instruction file configuration. */
export interface Config {
    path: string;
    maxBytes: number;
}
/** Personal instruction files remain below the service account home directory. */
export declare const Config: schema<Config>;
/** Required prompt and HTTP services. */
export declare const inject: string[];
/** @param ctx - Prompt and web-server lifecycle. @param config - Home-relative storage settings. */
export declare function apply(ctx: Context, config: Config): Promise<void>;
//# sourceMappingURL=index.d.ts.map