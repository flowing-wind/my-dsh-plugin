/** Browser validation for independently mounted traffic accounting. */
import { z } from 'zod';
/** Current traffic report and confirmation coordinates. */
export declare const trafficSnapshotSchema: z.ZodObject<{
    sessions: z.ZodRecord<z.ZodString, z.ZodObject<{
        incomingBytes: z.ZodNumber;
        outgoingBytes: z.ZodNumber;
        cny: z.ZodNumber;
    }, z.core.$strip>>;
    totals: z.ZodObject<{
        incomingBytes: z.ZodNumber;
        outgoingBytes: z.ZodNumber;
        cny: z.ZodNumber;
    }, z.core.$strip>;
    daily: z.ZodObject<{
        day: z.ZodString;
        outgoingBytes: z.ZodNumber;
        acknowledgedSteps: z.ZodNumber;
    }, z.core.$strip>;
    dailyCny: z.ZodNumber;
    windowCny: z.ZodNumber;
    throttled: z.ZodBoolean;
    requiredStep: z.ZodNullable<z.ZodNumber>;
    storageError: z.ZodBoolean;
    throttleDisabled: z.ZodBoolean;
    policy: z.ZodObject<{
        cnyPerGB: z.ZodNumber;
        windowMs: z.ZodNumber;
        windowCny: z.ZodNumber;
        throttledMbps: z.ZodNumber;
        dailyStepCny: z.ZodNumber;
        refreshMs: z.ZodNumber;
        checkpointMs: z.ZodNumber;
    }, z.core.$strip>;
}, z.core.$strip>;
/** Parsed network dashboard report. */
export type TrafficSnapshot = z.infer<typeof trafficSnapshotSchema>;
//# sourceMappingURL=wire.d.ts.map