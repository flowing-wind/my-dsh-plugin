/** Meter authenticated browser file transfers without buffering entire files. */
import type { Context } from '@deepseek-ai/cordis';
/**
 * Attach byte accounting and outbound pacing to Connection's authenticated body wrapper.
 * @param ctx - Traffic meter and HTTP extension event owner.
 */
export declare function meterBrowserTransfers(ctx: Context): void;
//# sourceMappingURL=browser-transfer.d.ts.map