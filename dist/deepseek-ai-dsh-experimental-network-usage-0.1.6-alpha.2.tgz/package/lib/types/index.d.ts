/** Optional durable public-traffic totals, spending confirmations, and shared egress pacing. */
import { Context, Service } from '@deepseek-ai/cordis';
import schema from '@deepseek-ai/schemastery';
import { z } from 'zod';
import type { SessionId } from '@deepseek-ai/dsh-session';
import type { TrafficPolicy } from './budget.ts';
/** Aggregate transfer ownership, including agentless Host requests. */
export type TrafficOwner = SessionId | 'host';
/** Persistent totals remain independent of Session and Workspace deletion. */
export declare const trafficDomain: {
    name: string;
    version: number;
    global: {
        schema: z.ZodObject<{
            sessions: z.ZodRecord<z.ZodString, z.ZodObject<{
                incomingBytes: z.ZodNumber;
                outgoingBytes: z.ZodNumber;
            }, z.core.$strip>>;
            retired: z.ZodDefault<z.ZodObject<{
                incomingBytes: z.ZodNumber;
                outgoingBytes: z.ZodNumber;
            }, z.core.$strip>>;
            daily: z.ZodObject<{
                day: z.ZodString;
                outgoingBytes: z.ZodNumber;
                acknowledgedSteps: z.ZodNumber;
            }, z.core.$strip>;
            samples: z.ZodArray<z.ZodObject<{
                time: z.ZodNumber;
                bytes: z.ZodNumber;
            }, z.core.$strip>>;
        }, z.core.$strip>;
        initial: {
            sessions: {};
            retired: {
                incomingBytes: number;
                outgoingBytes: number;
            };
            daily: {
                day: string;
                outgoingBytes: number;
                acknowledgedSteps: number;
            };
            samples: never[];
        };
    };
    tables: {};
};
/** Explicit deployment traffic policy and checkpoint frequency. */
export interface Config extends TrafficPolicy {
    /** Maximum normal interval between persisted traffic checkpoints, in milliseconds. */
    checkpointMs: number;
    /** Browser dashboard refresh interval in milliseconds. */
    refreshMs: number;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        networkUsage: NetworkUsage;
    }
}
/** Shared meter for proxy and browser transfers; confirmations never consume a model turn. */
export declare class NetworkUsage extends Service {
    private readonly config;
    static inject: string[];
    static Config: schema<Config>;
    private budget;
    private sessions;
    private retired;
    private readonly lifetime;
    private readonly waiting;
    private nextSendAt;
    private throttleRelease;
    private checkpoint;
    private checkpointError;
    /** @param ctx - Storage, authenticated transport, and Agent events. @param config - Deployment spending policy. */
    constructor(ctx: Context, config: Config);
    protected [Service.init](): Promise<void>;
    /**
     * Wait for the current spending warning to be acknowledged, or for midnight reset.
     * @param signal - Owning transfer or Agent cancellation.
     */
    allow(signal: AbortSignal): Promise<void>;
    /**
     * Apply spending consent and one shared throttle across outgoing streams.
     * @param bytes - Next bounded chunk length.
     * @param signal - Transfer cancellation.
     */
    pace(bytes: number, signal: AbortSignal): Promise<void>;
    /**
     * Account bytes transferred at a proxy or browser carrier.
     * @param owner - Session identity or agentless Host traffic.
     * @param direction - Direction relative to the server.
     * @param bytes - Transferred payload bytes, excluding IP/TCP retransmission overhead.
     */
    record(owner: TrafficOwner, direction: 'incoming' | 'outgoing', bytes: number): void;
    /**
     * Read dashboard counters and policy decisions.
     * @returns Detached lifetime totals and current enforcement state.
     */
    snapshot(): object;
}
export default NetworkUsage;
//# sourceMappingURL=index.d.ts.map