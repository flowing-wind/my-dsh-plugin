import type { ReactNode } from 'react';
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** @param props - Localized labels. @returns Global confirmation banner while transfers are paused. */
export declare function TrafficNotice({ t }: PropsLocale<'networkUsage'>): ReactNode;
/** @param props - Localized labels. @returns Historical traffic dashboard. */
export declare function NetworkPage({ t, useSessions, useWorkspaces }: PropsLocale<'networkUsage'> & PropsRuntime<'usage-dashboard.section'>): ReactNode;
//# sourceMappingURL=view.d.ts.map