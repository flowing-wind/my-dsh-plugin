/** Independently removable network dashboard and spending-confirmation banner. */
import type { Context } from '@deepseek-ai/cordis';
import { zh } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        networkUsage: keyof typeof zh;
    }
}
/** Browser registration dependencies. */
export declare const inject: string[];
/** @param ctx - Browser context. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map