/** Traffic monitoring and spending-confirmation copy. */
export declare const zh: {
    ungrouped: string;
    unnamed: string;
    archived: string;
    subtotal: string;
    todayUsage: string;
    todayCost: string;
    lifetimeUsage: string;
    lifetimeCost: string;
    remaining: string;
    nextThreshold: string;
    reset: string;
    needsConfirm: string;
    title: string;
    today: string;
    total: string;
    incoming: string;
    outgoing: string;
    session: string;
    host: string;
    cost: string;
    refresh: string;
    normal: string;
    throttled: string;
    window: string;
    disableThrottle: string;
    disabled: string;
    details: string;
    resumePolicy: string;
    warning: string;
    paused: string;
    confirm: string;
    pending: string;
    stale: string;
    note: string;
    error: string;
    loading: string;
    storageError: string;
    empty: string;
};
/** English labels for the same traffic actions. */
export declare const en: Record<keyof typeof zh, string>;
//# sourceMappingURL=locales.d.ts.map