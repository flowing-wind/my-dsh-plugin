/** Public-egress accounting and explicitly acknowledged calendar-day spending thresholds. */
/** Deployment policy; money is CNY and bandwidth is decimal Mbps. */
export interface TrafficPolicy {
    /** CNY charged per decimal GB of outgoing traffic. */
    cnyPerGB: number;
    /** Rolling observation window in milliseconds. */
    windowMs: number;
    /** Outgoing cost strictly above this amount activates throttling. */
    windowCny: number;
    /** Shared outgoing rate during throttling, in decimal Mbps. */
    throttledMbps: number;
    /** Additional CNY requiring confirmation within each Beijing calendar day. */
    dailyStepCny: number;
}
/** Durable daily accounting; acknowledgements apply to one Beijing calendar day. */
export interface DailyTraffic {
    day: string;
    outgoingBytes: number;
    acknowledgedSteps: number;
}
/**
 * Resolve the billing date independently of the machine's timezone.
 * @param now - Unix milliseconds.
 * @returns Beijing calendar date.
 */
export declare function billingDay(now: number): string;
/**
 * Convert public egress to a decimal-GB charge estimate.
 * @param bytes - Counted outbound bytes.
 * @param cnyPerGB - Configured CNY per 1,000,000,000 bytes.
 * @returns Unrounded CNY estimate.
 */
export declare function trafficCost(bytes: number, cnyPerGB: number): number;
/** Process-local rolling window backed by a separately persisted daily record. */
export declare class TrafficBudget {
    private readonly policy;
    private readonly samples;
    private windowBytes;
    private daily;
    private throttleDisabled;
    /** @param policy - Explicit price and thresholds. @param daily - Restored daily accounting. @param samples - Restored rolling-window observations. */
    constructor(policy: TrafficPolicy, daily: DailyTraffic, samples?: readonly {
        time: number;
        bytes: number;
    }[]);
    /**
     * Record actual outgoing bytes, coalescing same-millisecond samples.
     * @param bytes - Successfully transmitted bytes.
     * @param now - Observation time in Unix milliseconds.
     */
    record(bytes: number, now: number): void;
    /**
     * Read the current daily record and enforcement decisions.
     * @param now - Unix milliseconds.
     * @returns A detached daily record, current window cost, and required acknowledgement tier.
     */
    snapshot(now: number): {
        daily: DailyTraffic;
        windowCny: number;
        throttled: boolean;
        throttleDisabled: boolean;
        requiredStep: number | null;
    };
    /**
     * Disable pacing for the current over-budget episode; process restart clears this override.
     * @param now - Unix milliseconds.
     * @returns Whether an active throttle was disabled.
     */
    disableThrottle(now: number): boolean;
    /**
     * Acknowledge exactly the warning currently shown to the user.
     * @param day - Date displayed in the confirmation.
     * @param step - Spending tier displayed in the confirmation.
     * @param now - Unix milliseconds.
     * @returns Whether the confirmation still names the active warning.
     */
    acknowledge(day: string, step: number, now: number): boolean;
    /**
     * Copy the retained rolling observations.
     * @returns Detached observations for the next durable checkpoint.
     */
    observations(): {
        time: number;
        bytes: number;
    }[];
    private advance;
}
//# sourceMappingURL=budget.d.ts.map