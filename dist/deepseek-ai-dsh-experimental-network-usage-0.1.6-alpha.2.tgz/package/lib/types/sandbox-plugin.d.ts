/** Bubblewrap filesystem confinement plus a Session-owned proxy in a private network namespace. */
import { Context } from '@deepseek-ai/cordis';
import { LocalSandboxProvider } from '@deepseek-ai/dsh-sandbox-local';
import type { Config } from '@deepseek-ai/dsh-sandbox-local';
import type { ConfinedArgv, SandboxPolicy } from '@deepseek-ai/dsh-sandbox';
export type { Config } from '@deepseek-ai/dsh-sandbox-local';
/** Linux-only opt-in provider; direct external sockets cannot leave the network namespace. */
export declare class NetworkSandbox extends LocalSandboxProvider {
    static inject: string[];
    /** @param ctx - Session proxy service. @param options - Explicit Linux runner paths. */
    constructor(ctx: Context, options: Config);
    /**
     * Confine the command and expose only its Session's metered proxy socket.
     * @param argv - Exact command and arguments.
     * @param policy - Filesystem policy and required Session identity.
     * @param signal - Cancellation before spawn.
     * @returns Filesystem-enforcing argv with direct external networking disabled.
     */
    confine(argv: readonly string[], policy: SandboxPolicy, signal?: AbortSignal): Promise<ConfinedArgv>;
}
export default NetworkSandbox;
//# sourceMappingURL=sandbox-plugin.d.ts.map