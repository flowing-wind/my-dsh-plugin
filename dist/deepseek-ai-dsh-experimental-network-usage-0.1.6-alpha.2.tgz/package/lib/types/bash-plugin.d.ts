/** Session-attributed proxy environment for approved full-access Bash commands. */
import { SandboxBashExecutor } from '@deepseek-ai/dsh-bash-sandbox';
import type { ShellExecRequest, ShellExecSpec } from '@deepseek-ai/dsh-shell';
/** Retains Bash sandbox and approval behavior while authenticating unconfined downloads. */
export declare class NetworkBashExecutor extends SandboxBashExecutor {
    static inject: string[];
    /**
     * Attach owner-specific proxy credentials only to unconfined commands.
     * @param request - Command and its already-resolved execution policy.
     * @returns Execution spec with metered proxy variables for full-access mode.
     */
    resolve(request: ShellExecRequest): ShellExecSpec;
}
export default NetworkBashExecutor;
//# sourceMappingURL=bash-plugin.d.ts.map