/** Host proxy pools and per-Session Unix listeners for the confined shell bridge. */
import { Context, Service } from '@deepseek-ai/cordis';
import schema from '@deepseek-ai/schemastery';
import type { SessionId } from '@deepseek-ai/dsh-session';
/** Dedicated socket directory and destination validation policy. */
export interface Config {
    socketDirectory: string;
    allowPrivateAddresses: boolean;
    connectTimeoutMs: number;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        networkProxy: NetworkProxy;
    }
}
/** Authenticated Host proxy and fixed-identity shell endpoints. */
export declare class NetworkProxy extends Service {
    readonly config: Config;
    static inject: string[];
    static Config: schema<Config>;
    private readonly tokens;
    private readonly pools;
    private readonly listeners;
    private url;
    /** @param ctx - Traffic meter and initiator attribution. @param config - Socket and proxy policy. */
    constructor(ctx: Context, config: Config);
    protected [Service.init](): Promise<void>;
    /**
     * Obtain a Session-owned Unix proxy socket for a network-isolated shell.
     * @param sessionId - Session whose traffic this socket records.
     * @returns Absolute Unix socket path, inaccessible to other Sessions' sandbox mounts.
     */
    socketFor(sessionId: SessionId): Promise<string>;
    private createSocket;
}
export default NetworkProxy;
//# sourceMappingURL=proxy-plugin.d.ts.map