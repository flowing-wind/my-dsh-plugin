import type { IncomingMessage, Server } from 'node:http';
import type { NetworkUsage, TrafficOwner } from './index.ts';
/** Transfer accounting operations consumed by proxy streams. */
export type TrafficMeter = Pick<NetworkUsage, 'allow' | 'pace' | 'record'>;
/** One listener belongs to one configured authentication or fixed Session resolver. */
export interface ProxyOptions {
    owner(request: IncomingMessage): TrafficOwner | undefined;
    allowPrivateAddresses: boolean;
    connectTimeoutMs: number;
}
/**
 * Create an unbound proxy; its caller owns listening and quiescent shutdown.
 * @param meter - Shared spending meter.
 * @param options - Identity, address policy, and connection timeout.
 * @returns Server plus an asynchronous close operation that cancels every transfer.
 */
export declare function createTrafficProxy(meter: TrafficMeter, options: ProxyOptions): {
    server: Server;
    close(): Promise<void>;
};
//# sourceMappingURL=proxy.d.ts.map