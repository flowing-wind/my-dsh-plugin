/** Two-phase directory downloads with server-enforced size confirmation. */
import type { Context } from '@deepseek-ai/cordis';
/** Temporary archive retention and explicit browser confirmation policy. */
export interface ArchiveConfig {
    archiveDirectory: string;
    confirmationBytes: number;
    archiveLifetimeMs: number;
}
/** @param ctx - Authenticated connection and durable Sessions. @param config - Archive storage and confirmation policy. */
export declare function registerArchives(ctx: Context, config: ArchiveConfig): void;
//# sourceMappingURL=archive-route.d.ts.map