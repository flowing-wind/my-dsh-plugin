/** Download actions for existing preview tabs and recorded agent deliveries. */
import { zh } from './locales.ts';
import type { Context } from '@deepseek-ai/cordis';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        workspaceDownload: keyof typeof zh;
    }
}
/** Slot owners and the existing deliverable event projection. */
export declare const inject: string[];
/** @param ctx - Browser slot registry and locale service. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=view.d.ts.map