/** Download and archive confirmation labels. */
/** Simplified Chinese download labels. */
export declare const zh: {
    download: string;
    preview: string;
    files: string;
    folder: string;
    compressing: string;
    confirmTitle: string;
    confirmSize: string;
    confirm: string;
    cancel: string;
    archiveError: string;
    skipped: string;
};
/** English download labels. */
export declare const en: {
    download: string;
    preview: string;
    files: string;
    folder: string;
    compressing: string;
    confirmTitle: string;
    confirmSize: string;
    confirm: string;
    cancel: string;
    archiveError: string;
    skipped: string;
};
//# sourceMappingURL=locales.d.ts.map