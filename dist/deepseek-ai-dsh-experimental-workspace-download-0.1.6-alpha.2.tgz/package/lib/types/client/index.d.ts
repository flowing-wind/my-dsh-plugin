/** Browser entry for workspace download actions. */
export { apply, inject } from './view.tsx';
//# sourceMappingURL=index.d.ts.map