/** Authenticated, cacheable default wallpaper for the optional skin. */
import type { Context } from '@deepseek-ai/cordis';
/** Wallpaper transport owner. */
export declare const inject: string[];
/** @param ctx - Authenticated browser connection. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map