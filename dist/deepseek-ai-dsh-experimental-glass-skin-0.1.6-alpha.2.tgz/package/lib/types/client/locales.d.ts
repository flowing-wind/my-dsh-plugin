/** Local skin settings labels. */
export declare const zh: {
    presets: string;
    oregairu: string;
    whiteout: string;
    title: string;
    opacity: string;
    hint: string;
    choose: string;
    reset: string;
    local: string;
    default: string;
    custom: string;
    error: string;
    busy: string;
};
/** English skin labels. */
export declare const en: {
    presets: string;
    oregairu: string;
    whiteout: string;
    title: string;
    opacity: string;
    hint: string;
    choose: string;
    reset: string;
    local: string;
    default: string;
    custom: string;
    error: string;
    busy: string;
};
//# sourceMappingURL=locales.d.ts.map