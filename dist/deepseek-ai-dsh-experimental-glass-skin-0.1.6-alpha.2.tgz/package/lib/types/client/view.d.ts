/** Removable glass surfaces and browser-local background controls. */
import type { Context } from '@deepseek-ai/cordis';
import { zh } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        glassSkin: keyof typeof zh;
    }
}
/** Optional settings and locale owners. */
export declare const inject: string[];
/** @param ctx - Browser plugin scope; removing it releases all visual effects. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=view.d.ts.map