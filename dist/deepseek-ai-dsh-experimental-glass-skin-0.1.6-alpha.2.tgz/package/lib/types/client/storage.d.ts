/** Browser-only wallpaper persistence, keeping image bytes out of Host requests. */
export declare function wallpaperStorage(value?: Blob | null): Promise<Blob | null>;
/** @param file - Browser-selected raster image. @returns Locally resized WebP image. */
export declare function compressWallpaper(file: File): Promise<Blob>;
//# sourceMappingURL=storage.d.ts.map