/** Browser-rendered menus for native select controls while the skin is enabled.
 * @returns disposer restoring native controls and removing the open menu.
 */
export declare function installSelectMenus(): () => void;
//# sourceMappingURL=select-menu.d.ts.map