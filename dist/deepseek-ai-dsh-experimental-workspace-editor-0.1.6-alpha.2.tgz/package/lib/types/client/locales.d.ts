/** Localized feature labels. */
export declare const zh: {
    edit: string;
    close: string;
    save: string;
    reload: string;
    loading: string;
    saved: string;
    dirty: string;
    discard: string;
    error: string;
};
/** English counterpart. */
export declare const en: Record<keyof typeof zh, string>;
//# sourceMappingURL=locales.d.ts.map