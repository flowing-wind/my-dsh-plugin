export { apply, inject } from './view.tsx';
//# sourceMappingURL=index.d.ts.map